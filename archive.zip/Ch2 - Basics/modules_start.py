# LinkedIn Learning Python course by Joe Marini
#


# TODO: import the math module, which contains features for working with mathematics
import math

# TODO: the math module contains lots of pre-built functions
print("The square root of 16 is",math.square.pi(16))

# TODO: in addition to functions, some modules contain useful constants 
print("Pi is", math.pi)

# TODO: try some of the math functions for yourself here:
